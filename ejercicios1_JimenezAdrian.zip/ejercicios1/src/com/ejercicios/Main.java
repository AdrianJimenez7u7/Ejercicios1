package com.ejercicios;

public class Main {
    public static void main(String[] args) {
        //variables tipo numerico
        byte vn = 3;
        System.out.println("Variable Byte: " + vn);
        short vn2 = 15;
        System.out.println("Variable Short: " + vn2);
        int vn3 = 3000;
        System.out.println("Variable Integer" + vn3);
        long vn4 = 100000;
        System.out.println("Variable Long" + vn4);
        //variables decimales
        float vn5 = 35.2f;
        System.out.println("variable Float: " + vn5);
        double vn6 = 32.55d;
        System.out.println("variable Double: " + vn6);
        //variables V/F
        boolean verd = true;
        System.out.println("variable Boolean: " + verd);
        boolean fals = false;
        System.out.println("variable Boolean: " + fals);
        //variables de caracter y cadena de texto
        char letra = 'a';
        System.out.println("caracter: " + letra);
        String nombre = "Adrian";
        System.out.println("cadena String: " + nombre);


    }
}
